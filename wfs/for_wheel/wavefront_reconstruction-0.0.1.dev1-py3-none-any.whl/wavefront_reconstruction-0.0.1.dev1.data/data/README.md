Library for reconstruction of wavefronts from the images acquired on a Shack-Hartmann sensor.

Usage:
1. from wfs_reconstruction import gui_wfs_reconstruction
2. gui_wfs_reconstruction.launch()

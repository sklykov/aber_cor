Usage of the package functionality:
1. from wfs_reconstruction import gui_wfs_reconstruction
2. gui_wfs_reconstruction.launch()
